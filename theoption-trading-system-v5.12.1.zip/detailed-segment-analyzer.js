/**
 * 詳細セグメント分析システム
 * 価格・テクニカル指標のパターンを細かく分析して類似度を計算
 */

// ========================================
// デバッグモード設定
// ========================================
// グローバル変数として定義（他のファイルと共有）
const globalScope = typeof window !== 'undefined' ? window : self;
if (typeof globalScope.DEBUG_MODE === 'undefined') {
  globalScope.DEBUG_MODE = false; // 本番ではfalse
}

// デバッグ用ログ関数
const dsaLog = globalScope.DEBUG_MODE ? console.log.bind(console) : () => {};
// ========================================

class DetailedSegmentAnalyzer {
  constructor() {
    // 各判定時間のセグメント設定（全て3セグメントに統一）
    // より長いセグメント期間で詳細な特徴を捉える
    this.segmentConfigs = {
      15:  {
        dataRange: 60,
        segmentDuration: 20,   // 10秒 → 20秒（3セグメント化）
        segmentCount: 3,        // 6 → 3
        atrMultiplier: 0.09,   // ATRの9%（BTC/JPY 0.005円相当）
        minThreshold: 0.0032   // 最小閾値 0.0032%
      },
      30:  {
        dataRange: 90,
        segmentDuration: 30,   // 15秒 → 30秒（3セグメント化）
        segmentCount: 3,        // 6 → 3
        atrMultiplier: 0.18,   // ATRの18%（BTC/JPY 0.010円相当）
        minThreshold: 0.0065   // 最小閾値 0.0065%
      },
      60:  {
        dataRange: 120,
        segmentDuration: 40,   // 20秒 → 40秒（3セグメント化）
        segmentCount: 3,        // 6 → 3
        atrMultiplier: 0.36,   // ATRの36%（BTC/JPY 0.020円相当）
        minThreshold: 0.013    // 最小閾値 0.013%
      },
      180: {
        dataRange: 240,
        segmentDuration: 80,   // 40秒 → 80秒（3セグメント化）
        segmentCount: 3,        // 6 → 3
        atrMultiplier: 0.36,   // ATRの36%（ドル円 0.020円 = 2銭相当）
        minThreshold: 0.013    // 最小閾値 0.013%
      },
      300: {
        dataRange: 300,
        segmentDuration: 100,  // 50秒 → 100秒（3セグメント化）
        segmentCount: 3,        // 6 → 3
        atrMultiplier: 0.36,   // ATRの36%（ドル円 0.020円 = 2銭相当）
        minThreshold: 0.013    // 最小閾値 0.013%
      }
    };

    // 動的閾値計算用のキャッシュ（時間枠別）
    this.thresholdCache = {
      15: { value: null, lastCalculated: 0 },
      30: { value: null, lastCalculated: 0 },
      60: { value: null, lastCalculated: 0 },
      180: { value: null, lastCalculated: 0 },
      300: { value: null, lastCalculated: 0 },
      cacheValidityMs: 60000 // キャッシュ有効期限（1分）
    };

    // 統計ベース閾値のパラメータ
    this.thresholdParams = {
      sampleSize: 100,           // 過去何件のデータで統計を取るか
      stdDevMultiplier: 0.25,    // 標準偏差の何倍を閾値とするか（ノイズレベル）
      minThreshold: 0.001,       // 最小閾値（0.001% = 極小の動き）
      maxThreshold: 0.1,         // 最大閾値（0.1% = 大きな動き）
      atrWeight: 0.6,            // ATRベース閾値の重み
      statsWeight: 0.4           // 統計ベース閾値の重み
    };
  }

  /**
   * 動的閾値を計算（時間枠別のATRベース閾値）
   * @param {number} timeframe - 判定時間（15, 30, 60, 180, 300）
   * @param {number} atrPercent - ATRパーセント
   * @returns {number} 計算された閾値（パーセント単位）
   */
  calculateDynamicThreshold(timeframe, atrPercent) {
    const now = Date.now();
    const config = this.segmentConfigs[timeframe];

    if (!config) {
      console.warn(`[DynamicThreshold] 未対応の時間枠: ${timeframe}`);
      return 0.01; // デフォルト値
    }

    // キャッシュが有効ならそれを返す
    const cache = this.thresholdCache[timeframe];
    if (cache && cache.value !== null &&
        (now - cache.lastCalculated) < this.thresholdCache.cacheValidityMs) {
      return cache.value;
    }

    let threshold = config.minThreshold;

    // ATRベースの閾値計算
    if (atrPercent && atrPercent > 0) {
      const atrBasedThreshold = atrPercent * config.atrMultiplier;
      // ATRベースと最小閾値の大きい方を使用
      threshold = Math.max(config.minThreshold, atrBasedThreshold);
    }

    // キャッシュに保存
    if (cache) {
      cache.value = threshold;
      cache.lastCalculated = now;
    }

    dsaLog(`[DynamicThreshold] ${timeframe}秒: ATR=${(atrPercent * 100).toFixed(4)}%, 係数=${config.atrMultiplier}, 閾値=${(threshold * 100).toFixed(4)}%`);

    return threshold;
  }

  /**
   * 価格履歴をセグメントに分割して詳細分析
   */
  analyzePriceSegments(priceHistory, timeframe = 60, atrPercent = null) {
    const config = this.segmentConfigs[timeframe];
    if (!config) {
      console.warn(`[DetailedSegment] 未対応の時間枠: ${timeframe}`);
      return this.getEmptyPriceSegmentAnalysis(6);
    }

    // 必要なデータ数を取得
    const relevantData = priceHistory.slice(-config.dataRange);

    if (relevantData.length < config.dataRange) {
      return this.getEmptyPriceSegmentAnalysis(config.segmentCount);
    }

    // 動的閾値を計算（時間枠別）
    const dynamicThreshold = this.calculateDynamicThreshold(timeframe, atrPercent);

    // セグメントごとに詳細分析
    const segments = [];
    const pointsPerSegment = Math.floor(relevantData.length / config.segmentCount);

    for (let i = 0; i < config.segmentCount; i++) {
      const startIdx = i * pointsPerSegment;
      const endIdx = (i === config.segmentCount - 1)
        ? relevantData.length
        : (i + 1) * pointsPerSegment;

      const segmentData = relevantData.slice(startIdx, endIdx);
      const segment = this.analyzePriceSegment(segmentData, i, dynamicThreshold);
      segments.push(segment);
    }

    return {
      segments: segments,
      pattern: this.generatePattern(segments),
      shapeHash: this.generateShapeHash(segments),
      segmentCount: config.segmentCount,
      summary: this.generateSummary(segments),
      threshold: dynamicThreshold  // デバッグ用に閾値も返す
    };
  }

  /**
   * 個別セグメントの詳細分析（フェーズ1-3の全特徴量）
   */
  analyzePriceSegment(data, index, dynamicThreshold = null) {
    if (data.length < 2) {
      return this.getEmptyPriceSegment(index);
    }

    const startPrice = data[0];
    const endPrice = data[data.length - 1];
    const maxPrice = Math.max(...data);
    const minPrice = Math.min(...data);
    const avgPrice = data.reduce((a, b) => a + b, 0) / data.length;

    // === フェーズ1: 基本統計 ===
    const change = endPrice - startPrice;
    const changePercent = (change / startPrice) * 100;

    // === フェーズ2: トレンド特徴 ===
    const slope = this.calculateLinearRegressionSlope(data);

    // ボラティリティ（標準偏差）
    const variance = data.reduce((sum, p) => sum + Math.pow(p - avgPrice, 2), 0) / data.length;
    const volatility = Math.sqrt(variance);

    // レンジ
    const range = maxPrice - minPrice;
    const rangePercent = (range / avgPrice) * 100;

    // 方向判定（rangePercentも考慮）
    const direction = this.classifyDirection(slope, changePercent, dynamicThreshold, rangePercent);

    // 上昇/下降の比率
    let upCount = 0, downCount = 0, flatCount = 0;
    for (let i = 1; i < data.length; i++) {
      const diff = data[i] - data[i-1];
      if (Math.abs(diff / data[i-1] * 100) < 0.005) {
        flatCount++;
      } else if (diff > 0) {
        upCount++;
      } else {
        downCount++;
      }
    }
    const totalMoves = upCount + downCount + flatCount;
    const upRatio = totalMoves > 0 ? upCount / totalMoves : 0.5;

    // === フェーズ3: 形状特徴 ===
    const peakIndex = data.indexOf(maxPrice);
    const troughIndex = data.indexOf(minPrice);
    const peakPosition = peakIndex / (data.length - 1);
    const troughPosition = troughIndex / (data.length - 1);

    // パターンタイプの分類
    const patternType = this.classifyPricePattern(data, slope, peakPosition, troughPosition);

    // 変化の強度（正規化された絶対値）
    const magnitude = Math.abs(changePercent);
    const normalizedMagnitude = this.normalizeToScale(magnitude, 0, 2, 0, 10); // 0-2%を0-10にマッピング

    return {
      index: index,

      // フェーズ1: 基本統計
      startPrice: startPrice,
      endPrice: endPrice,
      change: change,
      changePercent: changePercent,
      avgPrice: avgPrice,

      // フェーズ2: トレンド特徴
      slope: slope,
      direction: direction,
      magnitude: magnitude,
      normalizedMagnitude: normalizedMagnitude,
      volatility: volatility,
      range: range,
      rangePercent: rangePercent,
      upRatio: upRatio,

      // フェーズ3: 形状特徴
      maxPrice: maxPrice,
      minPrice: minPrice,
      peakPosition: peakPosition,
      troughPosition: troughPosition,
      patternType: patternType
    };
  }

  /**
   * テクニカル指標のセグメント分析
   */
  analyzeTechSegments(techHistory, timeframe = 60) {
    const config = this.segmentConfigs[timeframe];
    if (!config || !techHistory || techHistory.length < config.dataRange) {
      return this.getEmptyTechSegmentAnalysis(config ? config.segmentCount : 6);
    }

    const relevantData = techHistory.slice(-config.dataRange);
    const segments = [];
    const pointsPerSegment = Math.floor(relevantData.length / config.segmentCount);

    for (let i = 0; i < config.segmentCount; i++) {
      const startIdx = i * pointsPerSegment;
      const endIdx = (i === config.segmentCount - 1)
        ? relevantData.length
        : (i + 1) * pointsPerSegment;

      const segmentData = relevantData.slice(startIdx, endIdx);
      const segment = this.analyzeTechSegment(segmentData, i);
      segments.push(segment);
    }

    return {
      segments: segments,
      pattern: this.generatePattern(segments),
      shapeHash: this.generateShapeHash(segments),
      segmentCount: config.segmentCount
    };
  }

  /**
   * テクニカル指標セグメントの詳細分析
   */
  analyzeTechSegment(data, index) {
    if (data.length < 2) {
      return this.getEmptyTechSegment(index);
    }

    const startValue = data[0];
    const endValue = data[data.length - 1];
    const maxValue = Math.max(...data);
    const minValue = Math.min(...data);
    const avgValue = data.reduce((a, b) => a + b, 0) / data.length;

    const change = endValue - startValue;
    const changePercent = startValue !== 0 ? (change / Math.abs(startValue)) * 100 : 0;
    const slope = this.calculateLinearRegressionSlope(data);
    const direction = this.classifyDirection(slope, changePercent);

    const variance = data.reduce((sum, v) => sum + Math.pow(v - avgValue, 2), 0) / data.length;
    const volatility = Math.sqrt(variance);
    const range = maxValue - minValue;

    return {
      index: index,
      startValue: startValue,
      endValue: endValue,
      change: change,
      changePercent: changePercent,
      direction: direction,
      slope: slope,
      volatility: volatility,
      range: range,
      avgValue: avgValue
    };
  }

  /**
   * 線形回帰で傾きを計算
   */
  calculateLinearRegressionSlope(data) {
    const n = data.length;
    if (n < 2) return 0;

    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;

    for (let i = 0; i < n; i++) {
      sumX += i;
      sumY += data[i];
      sumXY += i * data[i];
      sumX2 += i * i;
    }

    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const avgY = sumY / n;

    // 価格に対する相対的な傾き（%）
    return avgY !== 0 ? (slope / avgY) * 100 : 0;
  }

  /**
   * 方向を分類（動的閾値ベース + range考慮）
   */
  classifyDirection(slope, changePercent, dynamicThreshold = null, rangePercent = null) {
    // 動的閾値が渡されていない場合は、デフォルト値を使用
    const threshold = dynamicThreshold !== null
      ? dynamicThreshold
      : this.thresholdParams.minThreshold;

    // changePercent と rangePercent の両方が小さい場合のみFLAT
    // （始値=終値でも変動があればUP/DOWN判定される）
    if (Math.abs(changePercent) < threshold &&
        (rangePercent === null || rangePercent < threshold)) {
      return 'FLAT';
    }

    return slope > 0 ? 'UP' : 'DOWN';
  }

  /**
   * 価格パターンを分類（フェーズ3）
   */
  classifyPricePattern(data, slope, peakPosition, troughPosition) {
    const len = data.length;
    const startValue = data[0];
    const endValue = data[len - 1];
    const maxValue = Math.max(...data);
    const minValue = Math.min(...data);

    const avgValue = data.reduce((a, b) => a + b, 0) / len;
    const variance = data.reduce((sum, v) => sum + Math.pow(v - avgValue, 2), 0) / len;
    const volatility = Math.sqrt(variance);
    const relativeVolatility = volatility / avgValue;

    // V字パターン: 谷が中央付近にある
    if (troughPosition > 0.3 && troughPosition < 0.7) {
      if (startValue > minValue && endValue > minValue) {
        const recoveryRatio = (endValue - minValue) / (startValue - minValue);
        if (recoveryRatio > 0.5) {
          return 'V_SHAPE';
        }
      }
    }

    // 逆V字パターン: 山が中央付近にある
    if (peakPosition > 0.3 && peakPosition < 0.7) {
      if (startValue < maxValue && endValue < maxValue) {
        const fallRatio = (maxValue - endValue) / (maxValue - startValue);
        if (fallRatio > 0.5) {
          return 'INVERTED_V_SHAPE';
        }
      }
    }

    // トレンドパターン
    if (Math.abs(slope) > 0.1) {
      if (slope > 0.1) {
        return 'UPTREND';
      } else if (slope < -0.1) {
        return 'DOWNTREND';
      }
    }

    // レンジ相場（低ボラティリティ）
    if (relativeVolatility < 0.002) {
      return 'RANGE';
    }

    // 複雑なパターン
    return 'COMPLEX';
  }

  /**
   * パターン文字列を生成
   */
  generatePattern(segments) {
    return segments.map(s => s.direction).join('-');
  }

  /**
   * 高速比較用のハッシュを生成
   */
  generateShapeHash(segments) {
    return segments.map(s => {
      if (s.direction === 'UP') return 'U';
      if (s.direction === 'DOWN') return 'D';
      return 'N';
    }).join('');
  }

  /**
   * パターン要約を生成
   */
  generateSummary(segments) {
    const directionCount = { UP: 0, DOWN: 0, FLAT: 0 };
    const patternTypeCount = {};

    segments.forEach(seg => {
      directionCount[seg.direction] = (directionCount[seg.direction] || 0) + 1;
      patternTypeCount[seg.patternType] = (patternTypeCount[seg.patternType] || 0) + 1;
    });

    const totalSegments = segments.length;
    const avgMagnitude = segments.reduce((sum, seg) => sum + seg.magnitude, 0) / totalSegments;
    const avgVolatility = segments.reduce((sum, seg) => sum + seg.volatility, 0) / totalSegments;

    return {
      upSegments: directionCount.UP,
      downSegments: directionCount.DOWN,
      flatSegments: directionCount.FLAT,
      upRatio: directionCount.UP / totalSegments,
      downRatio: directionCount.DOWN / totalSegments,
      flatRatio: directionCount.FLAT / totalSegments,
      avgMagnitude: avgMagnitude,
      avgVolatility: avgVolatility,
      dominantPattern: this.getDominantPattern(patternTypeCount)
    };
  }

  /**
   * 支配的なパターンタイプを取得
   */
  getDominantPattern(patternTypeCount) {
    let maxCount = 0;
    let dominant = 'COMPLEX';

    for (const [pattern, count] of Object.entries(patternTypeCount)) {
      if (count > maxCount) {
        maxCount = count;
        dominant = pattern;
      }
    }

    return dominant;
  }

  /**
   * 値を指定範囲にマッピング
   */
  normalizeToScale(value, inMin, inMax, outMin, outMax) {
    const clamped = Math.max(inMin, Math.min(inMax, value));
    return ((clamped - inMin) / (inMax - inMin)) * (outMax - outMin) + outMin;
  }

  /**
   * 空の価格セグメント分析を返す
   */
  getEmptyPriceSegmentAnalysis(segmentCount) {
    return {
      segments: Array(segmentCount).fill().map((_, i) => this.getEmptyPriceSegment(i)),
      pattern: Array(segmentCount).fill('FLAT').join('-'),
      shapeHash: 'N'.repeat(segmentCount),
      segmentCount: segmentCount,
      summary: {
        upSegments: 0,
        downSegments: 0,
        flatSegments: segmentCount,
        upRatio: 0,
        downRatio: 0,
        flatRatio: 1,
        avgMagnitude: 0,
        avgVolatility: 0,
        dominantPattern: 'RANGE'
      }
    };
  }

  /**
   * 空の価格セグメントを返す
   */
  getEmptyPriceSegment(index) {
    return {
      index: index,
      startPrice: 0,
      endPrice: 0,
      change: 0,
      changePercent: 0,
      avgPrice: 0,
      slope: 0,
      direction: 'FLAT',
      magnitude: 0,
      normalizedMagnitude: 0,
      volatility: 0,
      range: 0,
      rangePercent: 0,
      upRatio: 0.5,
      maxPrice: 0,
      minPrice: 0,
      peakPosition: 0.5,
      troughPosition: 0.5,
      patternType: 'RANGE'
    };
  }

  /**
   * 空のテクニカルセグメント分析を返す
   */
  getEmptyTechSegmentAnalysis(segmentCount) {
    return {
      segments: Array(segmentCount).fill().map((_, i) => this.getEmptyTechSegment(i)),
      pattern: Array(segmentCount).fill('FLAT').join('-'),
      shapeHash: 'N'.repeat(segmentCount),
      segmentCount: segmentCount
    };
  }

  /**
   * 空のテクニカルセグメントを返す
   */
  getEmptyTechSegment(index) {
    return {
      index: index,
      startValue: 0,
      endValue: 0,
      change: 0,
      changePercent: 0,
      direction: 'FLAT',
      slope: 0,
      volatility: 0,
      range: 0,
      avgValue: 0
    };
  }
}

// グローバルスコープに公開
// グローバルスコープに公開
(typeof window !== 'undefined' ? window : self).DetailedSegmentAnalyzer = DetailedSegmentAnalyzer;
